# B7-SCF final technical summary

- Development scenes: `5`
- Frames: `479`
- Frozen observations: `4943`
- Frozen TrackFragment: `646`
- GT PersonEpisode: `48`, evaluation only
- B6 micro association F1: `0.10304450`
- B7-FLOW micro association F1: `0.19599579`
- B7-CONSENSUS micro association F1: `0.03205919`
- B6 micro cross-person merge rate: `0.26666667`
- B7-FLOW micro cross-person merge rate: `0.40000000`
- B7-CONSENSUS micro cross-person merge rate: `0.23529412`
- B6 median perturbation ARI: `0.53446119`
- B7-CONSENSUS median perturbation ARI: `0.61780435`
- B7-CONSENSUS p10 perturbation ARI: `0.46925770`
- Improved scenes for primary B7-CONSENSUS: `0/5`
- Scientific decision: `FAIL`
- Operational decision: `FAIL`
- Direct/replay exact: `True`
- Test status: `SEALED`
- Test access count: `0`
- Detector/tracker/verifier/encoder training: `FORBIDDEN`
- Association training: `LOSO logistic regression on automatic pseudopairs only`
- Compute status: `FROZEN_AFTER_B7`
- B8 allowed: `false`

The calculation does not claim hazard understanding, operator-load reduction,
real-time operation, product maturity, or sealed-test performance.
